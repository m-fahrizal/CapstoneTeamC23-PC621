package com.example.capstoneproject.data

data class User(
    var name: String = "",
    var phone: String = "",
    var email: String = "",
    var password: String = ""
)